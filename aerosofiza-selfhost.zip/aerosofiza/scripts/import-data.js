#!/usr/bin/env node
/* Загрузка ранее выгруженных JSON-файлов в хранилище приложения.
   Назначение — база данных из DATABASE_URL или файлы DATA_DIR (если DATABASE_URL не задан).
   Запускайте при остановленном приложении, иначе работающий сервер перезапишет данные.
   Использование: node scripts/import-data.js [папка]   (по умолчанию ./data-export) */
'use strict';
const fs = require('fs'), path = require('path');
const { openStore } = require('../storage');
const KEYS = ['oto-store', 'chat-history'];
(async () => {
  const src = path.resolve(process.argv[2] || 'data-export');
  const st = await openStore({ dataDir: process.env.DATA_DIR || path.join(__dirname, '..', 'data'), keys: KEYS });
  for (const k of KEYS) {
    const f = path.join(src, k + '.json');
    if (!fs.existsSync(f)) { console.log(`— ${k}: файл не найден, пропуск`); continue; }
    st.set(k, JSON.parse(fs.readFileSync(f, 'utf8')));
    console.log(`✓ ${k} ← ${f}`);
  }
  await st.close();
  console.log('Готово. Хранилище:', st.kind);
})().catch(e => { console.error('Ошибка загрузки:', e.message); process.exit(1); });
