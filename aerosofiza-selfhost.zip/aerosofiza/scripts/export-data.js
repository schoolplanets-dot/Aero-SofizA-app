#!/usr/bin/env node
/* Выгрузка данных приложения в JSON-файлы.
   Источник — база данных из DATABASE_URL (или файлы DATA_DIR, если DATABASE_URL не задан).
   Использование: DATABASE_URL=mysql://... node scripts/export-data.js [папка]   (по умолчанию ./data-export) */
'use strict';
const fs = require('fs'), path = require('path');
const { openStore } = require('../storage');
const KEYS = ['oto-store', 'chat-history'];
(async () => {
  const out = path.resolve(process.argv[2] || 'data-export'); fs.mkdirSync(out, { recursive: true });
  const st = await openStore({ dataDir: process.env.DATA_DIR || path.join(__dirname, '..', 'data'), keys: KEYS });
  for (const k of KEYS) {
    const d = st.get(k);
    if (d == null) { console.log(`— ${k}: нет данных`); continue; }
    fs.writeFileSync(path.join(out, k + '.json'), JSON.stringify(d));
    console.log(`✓ ${k} → ${path.join(out, k + '.json')}`);
  }
  await st.close();
})().catch(e => { console.error('Ошибка выгрузки:', e.message); process.exit(1); });
