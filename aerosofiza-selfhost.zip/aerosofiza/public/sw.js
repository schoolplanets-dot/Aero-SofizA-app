/* Service worker Аэро-СофИзА: оболочка приложения доступна без сети, тайлы карты кэшируются. API и WebSocket не кэшируются. */
const SHELL = 'aero-shell-v1', TILES = 'aero-tiles-v1', TILE_MAX = 1500;
const SHELL_FILES = ['./', 'index.html', 'manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png', 'geodata/service_zones.geojson', 'geodata/aircrafts_positions.geojson', 'geodata/engineers_positions.geojson', 'geodata/service_vehicles_positions.geojson'];
self.addEventListener('install', e => { e.waitUntil(caches.open(SHELL).then(c => c.addAll(SHELL_FILES)).catch(() => {})); self.skipWaiting(); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => ![SHELL, TILES].includes(k)).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
const isTile = u => /tile\.openstreetmap\.org|basemaps\.cartocdn\.com|arcgisonline\.com/.test(u.host);
self.addEventListener('fetch', e => {
  const req = e.request; if (req.method !== 'GET') return; const u = new URL(req.url);
  if (u.pathname.startsWith('/api/') || u.pathname.startsWith('/ws/')) return;
  if (isTile(u)) {
    e.respondWith(caches.open(TILES).then(async c => { const hit = await c.match(req); if (hit) return hit; try { const r = await fetch(req); if (r.ok || r.type === 'opaque') { c.put(req, r.clone()); c.keys().then(ks => { if (ks.length > TILE_MAX) ks.slice(0, ks.length - TILE_MAX).forEach(k => c.delete(k)); }); } return r; } catch (err) { return hit || Response.error(); } }));
    return;
  }
  if (u.origin !== location.origin) return;
  // сеть в первую очередь (актуальная версия), при отсутствии сети — кэш
  e.respondWith(fetch(req).then(r => { if (r.ok) { const cp = r.clone(); caches.open(SHELL).then(c => c.put(req, cp)); } return r; }).catch(() => caches.match(req).then(r => r || caches.match('index.html'))));
});
